# nodejs 프로젝트

- JS를 이용한 Web Application Server 구현하기

## NodeJS 설치하기

- https://nodejs.org 에서 다운로드 받아 설치하기
- Nodejs 는 짝수 버전을 다운받아 설치한다. : `v20.x.x`

## 데몬 설치

- `npm install -g nodemon` : 소스코드 모니터링을 하면서 소스가 변경되면 자동으로 프로젝트를 재 시작하는 도구

## express 프로젝트 생성도구 설치

- `npm install -g express-21c`

## express framwork 프로젝트 생성

- `express 프로젝트명`
