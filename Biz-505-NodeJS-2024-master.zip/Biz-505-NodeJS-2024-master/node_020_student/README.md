# NodeJS 와 MySQL 연동

- NodeJS Server를 통하여 MySQL 과 연동하고, client 화면에 표현하기

## NodeJS 와 MySQL 을 연동하는 도구 설치

- `npm install mysql2` 명령을 터미널에서 입력하여 설치
- 2020년 이후로 업데이트가 되지 않는다. 가장 기본적인 실습을 하기 위하여 사용하기
