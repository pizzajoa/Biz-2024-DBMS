document.addEventListener('DOMContentLoaded', () => {
  console.log('Hello Korea')
})
